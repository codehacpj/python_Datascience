seaborn-data
============

Data repository for [seaborn](http://seaborn.pydata.org/) examples.

**This is not a general-purpose data archive.**

This repository exists only to provide a convenient target for the `seaborn.load_dataset` function to download sample datasets from. Its existence makes it easy to document seaborn without confusing things by spending time loading and munging data. However, the datasets may change or be removed at any time if they are no longer useful for the seaborn documentation.
